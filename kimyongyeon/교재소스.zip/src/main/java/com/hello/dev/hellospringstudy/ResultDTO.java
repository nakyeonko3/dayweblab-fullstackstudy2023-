package com.hello.dev.hellospringstudy;

public class ResultDTO {
}
