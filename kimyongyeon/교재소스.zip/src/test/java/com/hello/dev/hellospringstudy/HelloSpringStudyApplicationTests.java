package com.hello.dev.hellospringstudy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloSpringStudyApplicationTests {

    @Test
    void contextLoads() {
    }

}
